<?php
    //Membuat Fungsi/Function dengan Parameter
    function perkenalan($salam, $nama){
        echo $salam." <br>";
        echo "Selamat datang di channel ".$nama."<br>";
        echo "Jangan lupa like, coment, dan subscribe ya...<br>";
    }
    //Memanggil fungsi dengan parameter
    perkenalan("Assalamu'alaikum", "Eira Channel");
?>