<?php
    //membuat fungsi/Function
    function perkenalan(){
        echo "Selamat Pagi<br>";
        echo "Selamat datang di channel youtube Eira Channel<br>";
        echo "Jangan lupa like, comment, dan subscribe ya...<br>";
    }
    //Memanggil Fungsi
    perkenalan();
?>